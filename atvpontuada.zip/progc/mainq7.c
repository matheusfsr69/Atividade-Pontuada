#include <stdio.h>

int main() {
    int N;

    do {
        printf("Digite o valor de N (N >= 3): ");
        scanf("%d", &N);

        if (N < 3) {
            printf("Valor invalido! Tente novamente.\n");
        }

    } while (N < 3);

    int matriz[N][N];

    int inicio = 0;
    int fim = N - 1;
    int num = 1;

    while (inicio <= fim) {

        for (int j = inicio; j <= fim; j++) {
            matriz[inicio][j] = num++;
        }

        for (int i = inicio + 1; i <= fim; i++) {
            matriz[i][fim] = num++;
        }

        for (int j = fim - 1; j >= inicio; j--) {
            matriz[fim][j] = num++;
        }

        for (int i = fim - 1; i > inicio; i--) {
            matriz[i][inicio] = num++;
        }

        inicio++;
        fim--;
    }

    printf("\nEspiral gerada:\n\n");

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            printf("%4d", matriz[i][j]);
        }
        printf("\n");
    }

    return 0;
}