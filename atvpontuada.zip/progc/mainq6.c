#include <stdio.h>

int main() {
    int B, L, A;
    int i, j;

    do {
        printf("Digite a base da arvore (B - impar e >= 3): ");
        scanf("%d", &B);

        printf("Digite a largura do tronco (L - impar): ");
        scanf("%d", &L);

        printf("Digite a altura do tronco (A): ");
        scanf("%d", &A);

        if (B < 3 || B % 2 == 0 ||
            L % 2 == 0 ||
            L > B / 2 ||
            A < 2 || A > B / 2) {

            printf("\nValores invalidos! Digite novamente.\n\n");
        }

    } while (B < 3 || B % 2 == 0 ||
             L % 2 == 0 ||
             L > B / 2 ||
             A < 2 || A > B / 2);

    printf("\n");

    for (i = 1; i <= B; i += 2) {

        int espacos = (B - i) / 2;

        for (j = 0; j < espacos; j++) {
            printf(" ");
        }

        for (j = 0; j < i; j++) {
            printf("*");
        }

        printf("\n");
    }

    int espacosTronco = (B - L) / 2;

    for (i = 0; i < A; i++) {

        for (j = 0; j < espacosTronco; j++) {
            printf(" ");
        }

        for (j = 0; j < L; j++) {
            printf("*");
        }

        printf("\n");
    }

    return 0;
}