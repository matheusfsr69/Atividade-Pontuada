#include <stdio.h>

int main() {
    int altura, linha, i, espaco, valor;

    printf("Digite a altura do Triangulo de Pascal: ");
    scanf("%d", &altura);

    for (linha = 0; linha < altura; linha++) {
        
        for (espaco = 0; espaco < altura - linha - 1; espaco++) {
            printf(" "); 
        }

        valor = 1;

        for (i = 0; i <= linha; i++) {
            printf("%d ", valor);
            
            valor = valor * (linha - i) / (i + 1);
        }

        printf("\n");
    }

    return 0;
}