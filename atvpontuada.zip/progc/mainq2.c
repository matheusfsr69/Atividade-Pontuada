#include <stdio.h> 
int main() {
    int n;
    printf("Qual o valor de n? ");
    scanf("%d", &n);
    if(n < 2) {
        printf("O valor de n deve ser pelo menos 2.\n");
        return 0;
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n - i; j++) {
            printf(" ");
        }
        for (int j = 1; j <= 2 * i - 1; j++) {
            printf("%d", j);
        }
        for(int j = i - 1; j>= 1; j--) {
            printf("%d", j);
        }
        printf("\n");
    }
    return 0;
}
