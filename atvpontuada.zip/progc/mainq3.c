#include <stdio.h>
int main() {
    int altura, tipo;
    int i, j;
    printf("Informe a altura do triangulo: ");
    scanf("%d", &altura);   
    printf("Informe o tipo do triangulo (1, 2 ou 3): ");
    scanf("%d", &tipo);
    if (tipo == 1) {
        for (i = 1; i <= altura; i++) {
            for (j = 1; j <= i; j++) {
                printf("*");
            }
            printf("\n");
        }
    } else if (tipo == 2) {
        for (i = altura; i >= 1; i--) {
            for (j = 1; j <= i; j++) {
                printf("*");
            }
            printf("\n");
        }
    } else if (tipo == 3) {
        for (i = 1; i <= altura; i++) {
            for (j = 1; j <= altura - i; j++) {
                printf(" ");
            }
            for (j = 1; j <= i; j++) {
                printf("*");
            }
            printf("\n");
        }
    } else {
        printf("Tipo de triangulo invalido.\n");
    }
    return 0;
}



