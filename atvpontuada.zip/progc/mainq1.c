#include <stdio.h>
int main () {
    int h;
    int t;
    printf("Qual a altura do quadrado?");
scanf("%d", &h);
printf("O quadrado é vazado ou preenchido?\n");
printf("1 - Vazado\n");
printf("2 - Preenchido\n");
scanf("%d", &t);
if (t == 1) {
    for (int i = 0; i < h; i++) {
        for (int j = 0; j < h; j++) {
            if (i == 0 || i == h - 1 || j == 0 || j == h - 1) {
                printf("*");
            } else {
                printf(" ");
            }
        }
        printf("\n");
    }
} else if (t == 2) {
    for (int i = 0; i < h; i++) {
        for (int j = 0; j < h; j++) {
            printf("*");
        }
        printf("\n");
    }
} else {
    printf("Opção inválida.\n");
}
return 0;
}