#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAX_SEG 50000
#define PI 3.14159265358979323846

typedef struct {
    double x1, y1, x2, y2;
} Segmento;

Segmento segs[MAX_SEG];
int qtdSeg = 0;

void addSegment(double x1, double y1, double x2, double y2)
{
    segs[qtdSeg].x1 = x1;
    segs[qtdSeg].y1 = y1;
    segs[qtdSeg].x2 = x2;
    segs[qtdSeg].y2 = y2;
    qtdSeg++;
}

void koch(double x1, double y1,
          double x2, double y2,
          int n)
{
    if(n == 0)
    {
        addSegment(x1,y1,x2,y2);
        return;
    }

    double dx = x2 - x1;
    double dy = y2 - y1;

    double ax = x1 + dx/3.0;
    double ay = y1 + dy/3.0;

    double bx = x1 + 2.0*dx/3.0;
    double by = y1 + 2.0*dy/3.0;

    double ang = -PI/3.0;

    double px =
        ax + (bx-ax)*cos(ang)
           - (by-ay)*sin(ang);

    double py =
        ay + (bx-ax)*sin(ang)
           + (by-ay)*cos(ang);

    koch(x1,y1,ax,ay,n-1);
    koch(ax,ay,px,py,n-1);
    koch(px,py,bx,by,n-1);
    koch(bx,by,x2,y2,n-1);
}

void desenhaLinha(char **mat,
                  int H,
                  int W,
                  int x1,
                  int y1,
                  int x2,
                  int y2)
{
    int dx = abs(x2 - x1);
    int dy = abs(y2 - y1);

    int sx = (x1 < x2) ? 1 : -1;
    int sy = (y1 < y2) ? 1 : -1;

    int err = dx - dy;

    while(1)
    {
        if(y1 >= 0 && y1 < H &&
           x1 >= 0 && x1 < W)
            mat[y1][x1] = '*';

        if(x1 == x2 && y1 == y2)
            break;

        int e2 = 2 * err;

        if(e2 > -dy)
        {
            err -= dy;
            x1 += sx;
        }

        if(e2 < dx)
        {
            err += dx;
            y1 += sy;
        }
    }
}

int main()
{
    int N;

    do
    {
        printf("Nivel (1-3): ");
        scanf("%d",&N);

        if(N < 1 || N > 3)
            printf("Valor invalido!\n");

    } while(N < 1 || N > 3);

    qtdSeg = 0;

    double lado = 300.0;

    double h = lado * sqrt(3.0) / 2.0;

    double ax = 0;
    double ay = 0;

    double bx = lado;
    double by = 0;

    double cx = lado/2.0;
    double cy = h;

    koch(ax,ay,bx,by,N);
    koch(bx,by,cx,cy,N);
    koch(cx,cy,ax,ay,N);

    double minX = segs[0].x1;
    double maxX = segs[0].x1;
    double minY = segs[0].y1;
    double maxY = segs[0].y1;

    for(int i=0;i<qtdSeg;i++)
    {
        if(segs[i].x1 < minX) minX = segs[i].x1;
        if(segs[i].x2 < minX) minX = segs[i].x2;

        if(segs[i].x1 > maxX) maxX = segs[i].x1;
        if(segs[i].x2 > maxX) maxX = segs[i].x2;

        if(segs[i].y1 < minY) minY = segs[i].y1;
        if(segs[i].y2 < minY) minY = segs[i].y2;

        if(segs[i].y1 > maxY) maxY = segs[i].y1;
        if(segs[i].y2 > maxY) maxY = segs[i].y2;
    }

    double escala = 0.20;

    int W = (int)((maxX-minX)*escala) + 10;
    int H = (int)((maxY-minY)*escala) + 10;

    char **mat = malloc(H*sizeof(char*));

    for(int i=0;i<H;i++)
    {
        mat[i] = malloc(W+1);

        for(int j=0;j<W;j++)
            mat[i][j] = ' ';

        mat[i][W] = '\0';
    }

    for(int i=0;i<qtdSeg;i++)
    {
        int x1 = (int)((segs[i].x1-minX)*escala);
        int y1 = (int)((segs[i].y1-minY)*escala);

        int x2 = (int)((segs[i].x2-minX)*escala);
        int y2 = (int)((segs[i].y2-minY)*escala);

        y1 = H-1-y1;
        y2 = H-1-y2;

        desenhaLinha(
            mat,H,W,
            x1,y1,
            x2,y2
        );
    }

    printf("\n");

    for(int i=0;i<H;i++)
        printf("%s\n",mat[i]);

    for(int i=0;i<H;i++)
        free(mat[i]);

    free(mat);

    return 0;
}