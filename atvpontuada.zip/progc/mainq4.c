#include <stdio.h>

int main() {
    int largura, i, j, espacos;

    printf("Digite a largura central do losango: ");
    scanf("%d", &largura);

    
    if (largura % 2 == 0) {
        printf("A largura deve ser um numero impar!\n");
        return 0;
    }


    for (i = 1; i <= largura; i += 2) {

        espacos = (largura - i) / 2;

        
        for (j = 1; j <= espacos; j++) {
            printf(" ");
        }

        
        for (j = 1; j <= i; j++) {
            printf("X");
        }

        printf("\n");
    }

    
    for (i = largura - 2; i >= 1; i -= 2) {

        espacos = (largura - i) / 2;

        
        for (j = 1; j <= espacos; j++) {
            printf(" ");
        }

        
        for (j = 1; j <= i; j++) {
            printf("X");
        }

        printf("\n");
    }

    return 0;
}

        
     
